VEYROVA. BD — Free online shop

FILES
- index.html: complete mobile-friendly storefront. No paid libraries or backend needed.

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Replace each visible "৳ [দাম দিন]" with your actual price.
3. In each product button, replace data-price="দাম জানানো হয়নি" with your actual price.
4. If desired, replace the built-in SVG illustrations with real product photos.

WHATSAPP
The order buttons use WhatsApp number 8801762400371. Check that this is the correct business number before publishing.

FREE HOSTING OPTION: GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, e.g. veyrova-bd-shop.
3. Upload index.html to the repository root (top level).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait for the published URL to appear in Settings -> Pages. It will usually look like https://YOUR-USERNAME.github.io/veyrova-bd-shop/
GitHub's interface may change. You may also use Netlify Drop at https://app.netlify.com/drop by uploading the site folder/HTML, if available on your account.

NOTE
This is a static storefront. WhatsApp orders are sent by opening a pre-filled WhatsApp message; the site does not automatically collect orders, store customer data, or process online payments.
